package com.devsuperior.bds04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bds04Application {

	public static void main(String[] args) {
		SpringApplication.run(Bds04Application.class, args);
	}

}
